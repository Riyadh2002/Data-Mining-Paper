import pandas as pd, json
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import LabelEncoder

df = pd.read_pickle('../data/df_stage2.pkl')
df['IsCorrect'] = (df['Correct'] == 'YES').astype(int)
feat_cols = ['QuestionType', 'Complexity', 'ReasoningSteps']
CAT = {'QuestionType', 'Complexity'}

def run(features):
    X = df[features].copy()
    for c in features:
        if c in CAT:
            X[c] = LabelEncoder().fit_transform(X[c].astype(str))
        else:
            X[c] = X[c].astype(int)
    y = df['IsCorrect']
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    clf = DecisionTreeClassifier(max_depth=4, min_samples_leaf=15, random_state=42, class_weight='balanced')
    clf.fit(X_train, y_train)
    pred = clf.predict(X_test)
    return accuracy_score(y_test, pred)

full = run(feat_cols)
results = {'full (all 3 features)': full}
for drop in feat_cols:
    remaining = [c for c in feat_cols if c != drop]
    results[f'drop {drop}'] = run(remaining)

for k, v in results.items():
    print(k, round(v * 100, 2), '%')

with open('../data/ablation_results.json', 'w') as f:
    json.dump({k: round(v * 100, 2) for k, v in results.items()}, f, indent=2)
