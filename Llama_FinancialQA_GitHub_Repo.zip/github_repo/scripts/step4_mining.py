import pandas as pd, numpy as np, json
from sklearn.tree import DecisionTreeClassifier, export_text
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix, classification_report
from sklearn.preprocessing import LabelEncoder
from scipy.stats import chi2_contingency

df = pd.read_pickle('../data/df_stage2.pkl')
df['IsCorrect'] = (df['Correct'] == 'YES').astype(int)

results = {}

# ---------------- Decision Tree ----------------
feat_cols = ['QuestionType', 'Complexity', 'ReasoningSteps']
X = df[feat_cols].copy()
encoders = {}
for c in ['QuestionType', 'Complexity']:
    le = LabelEncoder()
    X[c] = le.fit_transform(X[c])
    encoders[c] = le
y = df['IsCorrect']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

clf = DecisionTreeClassifier(max_depth=4, min_samples_leaf=15, random_state=42, class_weight='balanced')
clf.fit(X_train, y_train)
y_pred = clf.predict(X_test)

acc = accuracy_score(y_test, y_pred)
prec, rec, f1, _ = precision_recall_fscore_support(y_test, y_pred, average='binary', pos_label=1, zero_division=0)
cm = confusion_matrix(y_test, y_pred).tolist()
importances = dict(zip(feat_cols, clf.feature_importances_.round(4).tolist()))

tree_rules = export_text(clf, feature_names=feat_cols)

results['decision_tree'] = {
    'train_size': len(X_train), 'test_size': len(X_test),
    'accuracy': round(acc, 4), 'precision': round(prec, 4),
    'recall': round(rec, 4), 'f1': round(f1, 4),
    'confusion_matrix': cm, 'confusion_matrix_labels': ['Incorrect(0)','Correct(1)'],
    'feature_importances': importances,
}
with open('../data/tree_rules.txt', 'w') as f:
    f.write(tree_rules)
print(tree_rules)

# baseline (majority class) for comparison
baseline_acc = max(y_test.mean(), 1 - y_test.mean())
results['decision_tree']['majority_class_baseline_accuracy'] = round(float(baseline_acc), 4)

# ---------------- Chi-square tests ----------------
def chi_test(col):
    ct = pd.crosstab(df[col], df['Correct'])
    chi2, p, dof, exp = chi2_contingency(ct)
    min_exp = exp.min()
    n = ct.values.sum()
    k = min(ct.shape) - 1 if min(ct.shape) > 1 else 1
    cramers_v = float(np.sqrt((chi2 / n) / k)) if k > 0 else None
    return {
        'variable': col, 'chi2': round(float(chi2), 3), 'dof': int(dof),
        'p_value': float(p), 'min_expected_count': round(float(min_exp), 2),
        'cramers_v': round(cramers_v, 4) if cramers_v is not None else None
    }

results['chi_square'] = [chi_test('QuestionType'), chi_test('Complexity')]

# Reasoning steps: use Spearman-style monotonic check via chi-square on binned steps
rs_ct = pd.crosstab(df['ReasoningSteps'].clip(upper=4), df['Correct'])
chi2, p, dof, exp = chi2_contingency(rs_ct)
results['chi_square'].append({
    'variable': 'ReasoningSteps(clipped at 4)', 'chi2': round(float(chi2),3),
    'dof': int(dof), 'p_value': float(p), 'min_expected_count': round(float(exp.min()),2)
})

# ---------------- Simple association-rule style patterns ----------------
# support/confidence for (QuestionType, Complexity) -> Incorrect, among errors
wrong = df[df['IsCorrect'] == 0]
rules = []
for (qt, cx), grp in df.groupby(['QuestionType', 'Complexity']):
    n = len(grp)
    if n < 15:
        continue
    n_wrong = (grp['IsCorrect'] == 0).sum()
    support = n / len(df)
    confidence = n_wrong / n
    if confidence >= 0.70:
        rules.append({
            'antecedent': f"QuestionType={qt} & Complexity={cx}",
            'consequent': 'Incorrect',
            'support': round(support, 3), 'confidence': round(confidence, 3), 'n': int(n)
        })
rules = sorted(rules, key=lambda r: -r['confidence'])
results['association_rules'] = rules

with open('../data/mining_results.json', 'w') as f:
    json.dump(results, f, indent=2)

print(json.dumps(results, indent=2))
