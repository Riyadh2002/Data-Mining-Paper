import pandas as pd, json

df = pd.read_pickle('../data/df_stage2.pkl')
df['IsCorrect'] = (df['Correct'] == 'YES').astype(int)

results = {}

# A. Overall
total = len(df)
correct = df['IsCorrect'].sum()
incorrect = total - correct
results['overall'] = {
    'total': int(total), 'correct': int(correct), 'incorrect': int(incorrect),
    'accuracy_pct': round(100*correct/total, 2), 'error_rate_pct': round(100*incorrect/total, 2)
}

# B. By Question Type
qt = df.groupby('QuestionType').agg(n=('IsCorrect','size'), correct=('IsCorrect','sum'))
qt['accuracy_pct'] = (100*qt['correct']/qt['n']).round(2)
qt['error_rate_pct'] = (100 - qt['accuracy_pct']).round(2)
qt = qt.sort_values('n', ascending=False)
results['by_question_type'] = qt.reset_index().to_dict('records')

# C. Error type distribution (excluding N/A = correct answers)
err = df[df['ErrorTypeStd'] != 'N/A']['ErrorTypeStd'].value_counts()
err_pct = (100*err/err.sum()).round(2)
results['error_type_distribution'] = [
    {'error_type': k, 'count': int(v), 'pct_of_errors': float(err_pct[k])} for k, v in err.items()
]

# D. Complexity vs Error
cx = df.groupby('Complexity').agg(n=('IsCorrect','size'), correct=('IsCorrect','sum'))
cx['accuracy_pct'] = (100*cx['correct']/cx['n']).round(2)
cx['error_rate_pct'] = (100 - cx['accuracy_pct']).round(2)
order = ['Simple','Moderate','Complex']
cx = cx.reindex(order)
results['by_complexity'] = cx.reset_index().to_dict('records')

# E. Reasoning Steps vs Error
rs = df.groupby('ReasoningSteps').agg(n=('IsCorrect','size'), correct=('IsCorrect','sum'))
rs['accuracy_pct'] = (100*rs['correct']/rs['n']).round(2)
rs['error_rate_pct'] = (100 - rs['accuracy_pct']).round(2)
results['by_reasoning_steps'] = rs.reset_index().to_dict('records')

# Cross tab: Question Type x Error Type (only errors), top combos with n>=5
cross = df[df['ErrorTypeStd']!='N/A'].groupby(['QuestionType','ErrorTypeStd']).size().reset_index(name='n')
cross = cross[cross['n']>=5].sort_values('n', ascending=False)
results['questiontype_x_errortype_top'] = cross.to_dict('records')

with open('../data/descriptive_stats.json','w') as f:
    json.dump(results, f, indent=2)

print(json.dumps(results, indent=2))
