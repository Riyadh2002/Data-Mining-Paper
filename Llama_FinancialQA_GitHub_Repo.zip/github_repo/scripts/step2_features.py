import pandas as pd, re, pickle

df = pd.read_pickle('../data/df_stage1.pkl')
with open('../data/table_map.pkl','rb') as f:
    table_map = pickle.load(f)

# fix the single junk 'v' ErrorType row -> Other (manually reviewed)
df.loc[df['ErrorTypeStd'] == 'UNRESOLVED', 'ErrorTypeStd'] = 'Other'

# ---------------------------------------------------------------
# Reasoning Steps: count arithmetic operators in the verifier's
# "Calculations" string (e.g. "6,609,866 / 15,973,855 * 100 = 41.38%").
# Definition (documented for the paper):
#   Reasoning Steps = number of distinct arithmetic operations
#   (+, -, *, /) applied BEFORE the final "=" sign.
#   A lone leading "-" (negative sign) is not counted as an operation.
# ---------------------------------------------------------------
def count_operations(calc_text):
    if not calc_text or not calc_text.strip():
        return 0
    expr = calc_text.split('=')[0]  # only the working, not the restated result
    # remove thousands-separator commas inside numbers so they aren't mistaken for ops
    expr = re.sub(r'(?<=\d),(?=\d{3}\b)', '', expr)
    # find operators that sit between two numeric tokens (real binary operators)
    ops = re.findall(r'(?<=[\d\)\%])\s*([+\-*/×÷])\s*(?=[\d\(])', expr)
    return len(ops)

df['ReasoningSteps'] = df['Calculations'].apply(count_operations)

# ---------------------------------------------------------------
# Question Type: rule-based, using question wording + the operator
# pattern actually used in the verified calculation.
# ---------------------------------------------------------------
def operator_set(calc_text):
    if not calc_text:
        return set()
    expr = calc_text.split('=')[0]
    expr = re.sub(r'(?<=\d),(?=\d{3}\b)', '', expr)
    return set(re.findall(r'(?<=[\d\)\%])\s*([+\-*/×÷])\s*(?=[\d\(])', expr))

def classify_question_type(row):
    q = row['Question'].lower()
    ops = operator_set(row['Calculations'])
    steps = row['ReasoningSteps']

    is_pct = ('%' in row['VerifiedAnswer']) or ('percent' in q) or ('percentage' in q) \
             or bool(re.search(r'\*\s*100|×\s*100', row['Calculations']))
    is_avg = bool(re.search(r'\baverage\b|\bmean\b', q))
    is_ratio_word = bool(re.search(r'\bratio\b|\bportion\b|\bproportion\b|\bfraction\b|\bpercent of\b', q))
    is_change_word = bool(re.search(r'\bchange\b|\bincrease\b|\bdecrease\b|\bgrowth\b', q))

    if steps == 0:
        return 'Direct Lookup'
    if steps >= 3:
        return 'Multi-step Calculation'
    if is_avg:
        return 'Average'
    if is_pct and (is_change_word or 'change' in q):
        return 'Percentage Change'
    if is_pct:
        return 'Percentage Change' if is_change_word else 'Ratio'
    if ops == {'+'}:
        return 'Addition'
    if ops == {'-'}:
        return 'Subtraction / Difference'
    if ops == {'/'} or (is_ratio_word and steps <= 2):
        return 'Ratio'
    if steps == 2:
        return 'Multi-step Calculation'
    return 'Other'

df['QuestionType'] = df.apply(classify_question_type, axis=1)

# ---------------------------------------------------------------
# Complexity: derived from Reasoning Steps (documented rule)
#   0-1 step  -> Simple
#   2 steps   -> Moderate
#   3+ steps  -> Complex
# ---------------------------------------------------------------
def complexity(steps):
    if steps <= 1:
        return 'Simple'
    elif steps == 2:
        return 'Moderate'
    else:
        return 'Complex'

df['Complexity'] = df['ReasoningSteps'].apply(complexity)

print(df['QuestionType'].value_counts())
print()
print(df['Complexity'].value_counts())
print()
print(df['ReasoningSteps'].value_counts().sort_index())

df.to_pickle('../data/df_stage2.pkl')
df.to_csv('../data/final_analytical_dataset.csv', index=False)
print("\nSaved data/final_analytical_dataset.csv with", len(df), "rows")
