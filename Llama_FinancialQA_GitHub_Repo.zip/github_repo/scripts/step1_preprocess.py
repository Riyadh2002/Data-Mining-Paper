import csv, json, re
import pandas as pd

# ---------- Load CSV (Gemini-verified) ----------
with open('../data/raw/dataset_-_Updated_ans_with_prompt.csv', newline='', encoding='utf-8') as f:
    r = csv.reader(f)
    header = next(r)
    rows = list(r)

cols = ['ID','Question','LlamaAnswer','VerifiedAnswer','Correct','Calculations','ErrorType','Reason']
csv_rows = [dict(zip(cols, row[:8])) for row in rows]
df = pd.DataFrame(csv_rows)

print("Raw CSV rows:", len(df))

# ---------- Log & drop duplicate IDs (keep first occurrence) ----------
dup_mask = df.duplicated(subset='ID', keep=False)
dup_log = df[dup_mask].sort_values('ID')
dup_log.to_csv('../data/audit_duplicate_ids.csv', index=False)
print("Duplicate ID rows (all occurrences):", len(dup_log))

df = df.drop_duplicates(subset='ID', keep='first').reset_index(drop=True)
print("After dedup:", len(df))

# ---------- Standardize Correct? ----------
df['Correct'] = df['Correct'].str.strip().str.upper()

# ---------- Fix junk / inconsistent ErrorType values ----------
def std_error_type(row):
    et = row['ErrorType'].strip()
    correct = row['Correct']
    low = et.lower()
    if correct == 'YES':
        return 'N/A'
    mapping = {
        'incomplete answer': 'Incomplete/Truncated Response',
        'incomplete/truncated response': 'Incomplete/Truncated Response',
        'hallucinated unsupported value': 'Unsupported/Hallucinated Value',
        'unsupported/hallucinated value': 'Unsupported/Hallucinated Value',
        'arithmetic error': 'Arithmetic Error',
        'wrong number selected': 'Wrong Number Selected',
        'wrong operation': 'Wrong Operation',
        'multi-step reasoning error': 'Multi-step Reasoning Error',
        'percentage error': 'Percentage Error',
        'other': 'Other',
    }
    if low in mapping:
        return mapping[low]
    # junk values like 'v', 'none', '' for a NO row -> flag as Other, log separately
    return 'UNRESOLVED'

df['ErrorTypeStd'] = df.apply(std_error_type, axis=1)

unresolved = df[df['ErrorTypeStd'] == 'UNRESOLVED']
unresolved.to_csv('../data/audit_unresolved_errortype.csv', index=False)
print("Unresolved ErrorType rows (flagged for manual review):", len(unresolved))

# ---------- Correct/ErrorType contradiction check ----------
contradiction = df[((df['Correct'] == 'YES') & (~df['ErrorType'].str.strip().str.upper().isin(['N/A','NONE','']))) ]
contradiction.to_csv('../data/audit_contradictions.csv', index=False)
print("Correct=YES but ErrorType not empty/N/A (auto-fixed to N/A):", len(contradiction))

# ---------- Load JSON table data ----------
files = ['../data/raw/llama_results_improved__1_.json','../data/raw/part_2_151_300_with_answers.json',
         '../data/raw/part_3_301_450_with_answers.json','../data/raw/part_4_451_600_with_answers.json',
         '../data/raw/part_5_601_750_with_answers.json','../data/raw/part_6_751_900_with_answers__2_.json',
         '../data/raw/part_7_901_919_with_answers.json']
table_map = {}
for fn in files:
    with open(fn) as f:
        data = json.load(f)
    for e in data:
        table_map[e['id']] = e

df['HasTable'] = df['ID'].map(lambda i: i in table_map)
print("Rows with matching table data:", df['HasTable'].sum())

# keep only rows with table (for rigorous feature extraction); log the rest
no_table = df[~df['HasTable']]
no_table.to_csv('../data/audit_no_table_match.csv', index=False)
df_final = df[df['HasTable']].reset_index(drop=True)
print("Final analytical dataset size:", len(df_final))

df_final.to_pickle('../data/df_stage1.pkl')
import pickle
with open('../data/table_map.pkl','wb') as f:
    pickle.dump(table_map, f)

print("\n--- Standardized ErrorType distribution ---")
print(df_final['ErrorTypeStd'].value_counts())
print("\n--- Correct distribution ---")
print(df_final['Correct'].value_counts())
