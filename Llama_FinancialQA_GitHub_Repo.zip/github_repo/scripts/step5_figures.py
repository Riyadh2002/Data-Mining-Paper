import pandas as pd, json, numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split

plt.rcParams.update({'font.size': 11, 'figure.dpi': 150})

df = pd.read_pickle('../data/df_stage2.pkl')
df['IsCorrect'] = (df['Correct'] == 'YES').astype(int)
with open('../data/descriptive_stats.json') as f:
    stats = json.load(f)
with open('../data/mining_results.json') as f:
    mining = json.load(f)

# Fig 1: Overall correct vs incorrect
fig, ax = plt.subplots(figsize=(5,4))
vals = [stats['overall']['correct'], stats['overall']['incorrect']]
bars = ax.bar(['Correct','Incorrect'], vals, color=['#4C9F70','#C0504D'])
for b,v in zip(bars, vals):
    ax.text(b.get_x()+b.get_width()/2, v+5, str(v), ha='center')
ax.set_ylabel('Number of Questions')
ax.set_title(f'Figure 1. Overall Llama 3.2 Accuracy (n={stats["overall"]["total"]})\nAccuracy = {stats["overall"]["accuracy_pct"]}%')
plt.tight_layout()
plt.savefig('../figures/fig1_overall.png')
plt.close()

# Fig 2: Error rate by Question Type
qt = pd.DataFrame(stats['by_question_type']).sort_values('error_rate_pct', ascending=True)
fig, ax = plt.subplots(figsize=(7,5))
bars = ax.barh(qt['QuestionType'], qt['error_rate_pct'], color='#C0504D')
for b,n in zip(bars, qt['n']):
    ax.text(b.get_width()+1, b.get_y()+b.get_height()/2, f"n={n}", va='center', fontsize=9)
ax.set_xlabel('Error Rate (%)')
ax.set_title('Figure 2. Llama 3.2 Error Rate by Question Type')
ax.set_xlim(0, 100)
plt.tight_layout()
plt.savefig('../figures/fig2_by_question_type.png')
plt.close()

# Fig 3: Error type distribution
et = pd.DataFrame(stats['error_type_distribution']).sort_values('count', ascending=True)
fig, ax = plt.subplots(figsize=(7,5))
bars = ax.barh(et['error_type'], et['count'], color='#4472C4')
for b,p in zip(bars, et['pct_of_errors']):
    ax.text(b.get_width()+1, b.get_y()+b.get_height()/2, f"{p}%", va='center', fontsize=9)
ax.set_xlabel('Number of Errors')
ax.set_title(f'Figure 3. Error Type Distribution (n={stats["overall"]["incorrect"]} errors)', fontsize=13)
plt.tight_layout()
plt.savefig('../figures/fig3_error_types.png')
plt.close()

# Fig 4: Error rate by Complexity
cx = pd.DataFrame(stats['by_complexity'])
order = ['Simple','Moderate','Complex']
cx['Complexity'] = pd.Categorical(cx['Complexity'], categories=order, ordered=True)
cx = cx.sort_values('Complexity')
fig, ax = plt.subplots(figsize=(5,4))
bars = ax.bar(cx['Complexity'], cx['error_rate_pct'], color='#ED7D31')
for b,n in zip(bars, cx['n']):
    ax.text(b.get_x()+b.get_width()/2, b.get_height()+1, f"n={n}", ha='center', fontsize=9)
ax.set_ylabel('Error Rate (%)')
ax.set_ylim(0,100)
ax.set_title('Figure 4. Error Rate by Question Complexity')
plt.tight_layout()
plt.savefig('../figures/fig4_by_complexity.png')
plt.close()

# Fig 5: Error rate by Reasoning Steps
rs = pd.DataFrame(stats['by_reasoning_steps']).sort_values('ReasoningSteps')
fig, ax = plt.subplots(figsize=(6,4))
ax.plot(rs['ReasoningSteps'], rs['error_rate_pct'], marker='o', color='#C0504D')
for x,y,n in zip(rs['ReasoningSteps'], rs['error_rate_pct'], rs['n']):
    ax.annotate(f"n={n}", (x,y), textcoords="offset points", xytext=(0,8), ha='center', fontsize=8)
ax.set_xlabel('Reasoning Steps (arithmetic operations required)')
ax.set_ylabel('Error Rate (%)')
ax.set_ylim(0,105)
ax.set_title('Figure 5. Error Rate by Number of Reasoning Steps')
plt.tight_layout()
plt.savefig('../figures/fig5_by_reasoning_steps.png')
plt.close()

# Fig 6: Decision tree feature importance + tree plot
fig, ax = plt.subplots(figsize=(5,4))
imp = mining['decision_tree']['feature_importances']
ax.bar(imp.keys(), imp.values(), color='#70AD47')
ax.set_ylabel('Feature Importance (Gini)')
ax.set_title('Figure 6a. Decision Tree Feature Importance')
plt.tight_layout()
plt.savefig('../figures/fig6a_feature_importance.png')
plt.close()

feat_cols = ['QuestionType', 'Complexity', 'ReasoningSteps']
X = df[feat_cols].copy()
for c in ['QuestionType', 'Complexity']:
    le = LabelEncoder()
    X[c] = le.fit_transform(X[c])
y = df['IsCorrect']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)
clf = DecisionTreeClassifier(max_depth=4, min_samples_leaf=15, random_state=42, class_weight='balanced')
clf.fit(X_train, y_train)

fig, ax = plt.subplots(figsize=(14,8))
plot_tree(clf, feature_names=feat_cols, class_names=['Incorrect','Correct'],
          filled=True, rounded=True, fontsize=8, ax=ax)
ax.set_title('Figure 6b. Decision Tree Structure (max_depth=4)')
plt.tight_layout()
plt.savefig('../figures/fig6b_tree_structure.png')
plt.close()

print("All figures saved to figures/")
import os
print(os.listdir('../figures'))
